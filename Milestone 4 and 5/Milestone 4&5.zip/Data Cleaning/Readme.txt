NCDS Data Analysis Cont is clean version.
NCDS Data Analysis is a little bit messy because we did a lot of trials on the dataset.